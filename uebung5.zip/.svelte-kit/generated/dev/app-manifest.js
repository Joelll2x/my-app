// empty during dev
export const immutable = [];
export const prerendered = [];

export const assets = [
	{"path":"images/crimson-valley.png"},
	{"path":"images/echoes-of-tomorrow.png"},
	{"path":"images/midnight-harbor.png"},
	{"path":"images/neon-horizon.png"},
	{"path":"images/orbit-of-strangers.png"},
	{"path":"images/paper-cranes.png"},
	{"path":"images/silent-meridian.png"},
	{"path":"images/the-last-lighthouse.png"},
	{"path":"robots.txt"}
];

export const routes = [
	{"id":"/","page":true,"endpoint":false},
	{"id":"/movies","page":true,"endpoint":false}
];