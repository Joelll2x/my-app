<script>
	import movies from '#lib/data/movies.json';
	import MovieCard from '#lib/components/MovieCard.svelte';
</script>

<h1 class="mb-4">Movies</h1>

<div class="row row-cols-1 row-cols-sm-2 row-cols-lg-4 g-4">
	{#each movies as movie}
		<div class="col">
			<MovieCard {movie} />
		</div>
	{/each}
</div>